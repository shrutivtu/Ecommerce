
/*Home Page*/

function newfunction(stringjson){
    var obj=JSON.parse(stringjson);
    var maindiv1,img,textsec1,text1,node1,text2,node2,text3,node3;
    var l=obj.length;
    var pelement1=document.getElementById("clothing-sec");
    var pelement2=document.getElementById("accessories-sec");
    for(var i=0;i<obj.length;i++){
        if(obj[i].isAccessory===false){
            let id=obj[i]["id"];
            maindiv1=document.createElement("div");
            maindiv1.classList.add("cloth-box");
            img=document.createElement("IMG");
            img.setAttribute("src",obj[i].photos[0]);
            img.classList.add("img-class");
            textsec1=document.createElement("div");
            textsec1.classList.add('textsec1');
            text1=document.createElement("h3");
            node1=document.createTextNode(obj[i].name);
            text1.appendChild(node1);
            text1.classList.add("text1")
            text2=document.createElement("p");
            node2=document.createTextNode(obj[i].brand);
            text2.appendChild(node2);
            text2.classList.add("text2");
            text3=document.createElement("p");
            node3=document.createTextNode("Rs. "+obj[i].price);
            text3.appendChild(node3);
            text3.classList.add("text3");
            maindiv1.appendChild(img);
            textsec1.appendChild(text1);
            textsec1.appendChild(text2);
            textsec1.appendChild(text3);
            maindiv1.appendChild(textsec1);
            pelement1.appendChild(maindiv1);

            /*Product Page condition*/

            img.addEventListener("click",function(){
                 location.href="product.html?p="+id;
            });

        }else{
            let id=obj[i]["id"];
            maindiv1=document.createElement("div");
            maindiv1.classList.add("cloth-box");
            img=document.createElement("IMG");
            img.setAttribute("src",obj[i].photos[0]);
            img.classList.add("img-class");
            textsec1=document.createElement("div");
            textsec1.classList.add('textsec1');
            text1=document.createElement("h3");
            node1=document.createTextNode(obj[i].name);
            text1.appendChild(node1);
            text1.classList.add("text1")
            text2=document.createElement("p");
            node2=document.createTextNode(obj[i].brand);
            text2.appendChild(node2);
            text2.classList.add("text2");
            text3=document.createElement("p");
            node3=document.createTextNode("Rs. "+obj[i].price);
            text3.appendChild(node3);
            text3.classList.add("text3");
            maindiv1.appendChild(img);
            textsec1.appendChild(text1);
            textsec1.appendChild(text2);
            textsec1.appendChild(text3);
            maindiv1.appendChild(textsec1);
            pelement2.appendChild(maindiv1);

            /*Product Page condition*/

            img.addEventListener("click",function(){
                location.href="product.html?p="+id;
            });
        }
    }
}

$.get('https://5d76bf96515d1a0014085cf9.mockapi.io/product',function(data,status){
        var response=data;
        var jsonstring=JSON.stringify(response);
        newfunction(jsonstring);
})

var cartbut=document.getElementById('cart-button');
cartbut.addEventListener("click",function(){
    location.href="checkout.html";
});