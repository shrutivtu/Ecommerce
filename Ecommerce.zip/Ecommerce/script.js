$('.slider').slick({
	dots:false,
	arrow:false,
	autoplay:true,
	autoplayspeed:1000,
	infinite:true,
	fade:true
});

/*var http=new XMLHttpRequest();
http.onreadystatechange=funtcion(){
	if(this.status===4){
		if(this.status===200){
			var response=JSON.parse(this.responseText);
			console.log(response);
		}
		else{
			console.log('failed');
		}
	}
}
http.open('GET','https://5d76bf96515d1a0014085cf9.mockapi.io/product',true);
http.send()*/