let fid = [];
let itemcount=1;
let totalprice=0;
let c=1;
function createnodes(name,price,photo){
	var totalitemvalue=document.getElementById('totalitemvalue');
	totalitemvalue.innerHTML=totalitem;
	totalprice=totalprice+parseInt(price);
	var left=document.getElementById('left');
			productbox=document.createElement('div');
			productbox.classList.add('productbox');
			
			var leftpor=document.createElement('div');
			var img=document.createElement('img');
			img.setAttribute("src",photo);
			img.classList.add('small-checkimg');
			leftpor.appendChild(img);

			productbox.appendChild(leftpor);

			var rightpor=document.createElement('div');
			rightpor.classList.add('rightpor');

			var nameheading=document.createElement('h3');
			var nametext=document.createTextNode(name);
			nameheading.appendChild(nametext);
			rightpor.appendChild(nameheading);

			var itemcountheading=document.createElement('p');
			var itemcountheadingtext=document.createTextNode("x"+itemcount);
			itemcountheading.appendChild(itemcountheadingtext);
			rightpor.appendChild(itemcountheading);

			var pricetag=document.createElement('p');
			var pricetagvalue=document.createTextNode("Amount: Rs "+price);
			pricetag.appendChild(pricetagvalue);
			rightpor.appendChild(pricetag);

			productbox.appendChild(rightpor);
			left.appendChild(productbox);

			if(c==totalitem){
				let right=document.getElementById('right');
				let totalamtbox=document.createElement('div');
					totalamtbox.classList.add('totalamtbox');

					let totalh3=document.createElement('h3');
					let totaltext=document.createTextNode('Total Amount');
					totalh3.classList.add('totalh3');
					totalh3.appendChild(totaltext);

					let billp=document.createElement('p');
					let billptext=document.createTextNode('Amount: Rs ');
					billp.appendChild(billptext);
					
					let totp=document.createElement('span');
					let totptext=document.createTextNode(totalprice);
					totp.appendChild(totptext);
					totp.classList.add('totp');
					billp.classList.add('billp');
					billp.appendChild(totp);

					let placeorderbutton=document.createElement('button');
					let placeordertext=document.createTextNode('Place Order');
					placeorderbutton.appendChild(placeordertext);
					placeorderbutton.classList.add('placeorderbutton');
					placeorderbutton.addEventListener("click",function(){
            			location.href="orderconfirm.html";
        			});

					totalamtbox.appendChild(totalh3);
					totalamtbox.appendChild(billp);
					totalamtbox.appendChild(placeorderbutton);

				right.appendChild(totalamtbox); 
			}
			c++;
}

function anotherfunc(response){
	$.post('https://5d76bf96515d1a0014085cf9.mockapi.io/order',response,function(data,status){
		fresponse = data;
	})
}

let products=[];
let ids=[];
let totalitem=0;


if(localStorage.getItem('products')){
    products=JSON.parse(localStorage.getItem('products'));
    for (let i = 0; i < products.length; i++) {
    	ids.push(products[i]['productId']);
	}
	totalitem=products.length;
	for (let i = 0; i < ids.length; i++) {
		$.get("https://5d76bf96515d1a0014085cf9.mockapi.io/product"+"/"+parseInt(ids[i]),function(data,status){
	    	var response=data;
	    	createnodes(response.name,response.price,response.photos[0],response);
	    	anotherfunc(response);
		})
	}	
}