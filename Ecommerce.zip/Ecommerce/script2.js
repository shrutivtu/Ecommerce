var currloc=window.location;
var strid=window.location.search;
var cnum=0;
var id=strid.charAt(strid.length-1);
let url="https://5d76bf96515d1a0014085cf9.mockapi.io/product"+"/"+id;
    $.get(url,function(data,status){
        var response=data;
        var prodsec=document.getElementById('prod-sec');
        var photosec=document.createElement('div');
        photosec.classList.add("photo-sec");
        var img=document.createElement('IMG');
        img.setAttribute("src",response.photos[0]);
        img.classList.add("main-img");
        photosec.appendChild(img);
        prodsec.appendChild(photosec);

        //Detail Section

        var detailsec=document.createElement('div');
        detailsec.classList.add("detail-sec");

        var mainheading=document.createElement("h2");
        var texth2=document.createTextNode(response.name);
        mainheading.appendChild(texth2);
        mainheading.classList.add("mainheading");

        var sub1=document.createElement('h3');
        var textsub1=document.createTextNode(response.brand);
        sub1.appendChild(textsub1);
        sub1.classList.add("brand-name");

        var sub2=document.createElement('h3');
        var textsub2=document.createTextNode("Price: Rs ");
        sub2.appendChild(textsub2);
        var proprice=document.createElement('span');
        var pricenum=document.createTextNode(response.price);
        proprice.appendChild(pricenum);
        sub2.appendChild(proprice);
        sub2.classList.add("propageprice");

        var sub3=document.createElement('h3');
        var textsub3=document.createTextNode("Description");
        sub3.appendChild(textsub3);
        sub3.classList.add("description");

        var desctag=document.createElement('p');
        var desctext=document.createTextNode(response.description);
    	desctag.appendChild(desctext);
    	desctag.classList.add("desctext");

    	var imgheading=document.createElement('h3');
        var imgheadingtext=document.createTextNode("Product Review");
        imgheading.classList.add("imgheading");
        imgheading.appendChild(imgheadingtext);

        var pelecont=document.createElement('div');
        	pelecont.classList.add('pelecont');
        for(var i=0;i<response.photos.length;i++){
        	var pelem=document.createElement('div');
        	pelem.classList.add('small-img-box');
        	var smallimg=document.createElement('img');
        	smallimg.setAttribute("src",response.photos[i]);
        	smallimg.classList.add("small-img");
        	pelem.appendChild(smallimg);
        	pelecont.appendChild(pelem);

        	pelem.addEventListener("click",function(){
                 img.setAttribute("src",response.photos[i]);
        		 photosec.appendChild(img);
            });
        }

        var buybutton=document.createElement('button');
        var btntext=document.createTextNode("Buy Now");
        buybutton.appendChild(btntext);
        buybutton.classList.add('buy-button');
        buybutton.addEventListener("click",function(){
            let products=[];
            if(localStorage.getItem('products')){
                products=JSON.parse(localStorage.getItem('products'));
                console.log(products);
            }
            products.push({'productId':id})
            localStorage.setItem('products',JSON.stringify(products));
            document.getElementById('c-badge').innerHTML=products.length;
        });
        var cartbut=document.getElementById('cart-but');
        cartbut.addEventListener("click",function(){
            location.href="checkout.html";
        });

        detailsec.appendChild(mainheading);
        detailsec.appendChild(sub1);
        detailsec.appendChild(sub2);
        detailsec.appendChild(sub3);
        detailsec.appendChild(desctag);
        detailsec.appendChild(imgheading);
        detailsec.appendChild(pelecont);
        detailsec.appendChild(buybutton);
        prodsec.appendChild(detailsec);
})